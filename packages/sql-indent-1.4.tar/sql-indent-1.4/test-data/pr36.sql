begin
  if a = b then
    for rec in cur loop
      if c = d then
        inst1;
      end if;
    end loop;
  end if;
end;
/

-- Local Variables:
-- mode: sql
-- tab-width: 2
-- indent-tabs-mode: nil
-- sql-product: oracle
-- End:
